Alpha release of the VCD-db Client. (0.1)

The client uses the SOAP interface to communicate with
an existing VCD-db web.
VCD-db 0.96 or later must be running in order for the client to work.
The client is a win32 application which requires the .NET 1.1 framework to be installed.

Further information can be found on VCD-db homepage.
http://vcddb.konni.com & http://sourceforge.net/projects/vcd-db
